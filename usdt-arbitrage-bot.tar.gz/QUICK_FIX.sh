#!/bin/bash

# Quick one-liner fix
cd /Users/srijan/Desktop/usdt-arbitrage-bot && chmod +x fix-localhost.sh && ./fix-localhost.sh