// READY FOR CURSOR: Press Cmd+K and say "Create comprehensive TypeScript types for crypto arbitrage trading"
export interface ExchangePrice {
  // Cursor will generate this
}
