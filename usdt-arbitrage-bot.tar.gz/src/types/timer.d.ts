declare global {
  type Timer = NodeJS.Timeout;
}

export {};