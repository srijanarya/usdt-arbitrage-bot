import WebSocket from 'ws';
import crypto from 'crypto';
import axios, { AxiosInstance } from 'axios';
import EventEmitter from 'events';

interface CoinDCXOptions {
  apiKey: string;
  apiSecret: string;
  testMode?: boolean;
}

interface OrderRequest {
  market: string;
  side: 'buy' | 'sell';
  price_per_unit?: number;
  total_quantity?: number;
  order_type: 'limit_order' | 'market_order';
}

interface Balance {
  currency: string;
  balance: number;
  locked_balance: number;
}

interface Ticker {
  ask: string;
  bid: string;
  high: string;
  low: string;
  volume: string;
  timestamp: number;
}

export class CoinDCXClient extends EventEmitter {
  private ws: WebSocket | null = null;
  private apiKey: string;
  private apiSecret: string;
  private baseURL: string;
  private wsURL: string;
  private reconnectTimeout: number = 1000;
  private maxReconnectAttempts: number = 10;
  private reconnectAttempts: number = 0;
  private rateLimit: number = 10; // requests/sec
  private lastRequest: number[] = [];
  private client: AxiosInstance;
  private pingInterval: NodeJS.Timeout | null = null;
  private isConnected: boolean = false;

  constructor(options: CoinDCXOptions) {
    super();
    this.apiKey = options.apiKey;
    this.apiSecret = options.apiSecret;
    this.baseURL = options.testMode ? 'https://api.coindcx.com' : 'https://api.coindcx.com';
    this.wsURL = options.testMode ? 'wss://stream.coindcx.com' : 'wss://stream.coindcx.com';
    
    this.client = axios.create({
      baseURL: this.baseURL,
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      }
    });
  }

  connect() {
    if (this.isConnected) {
      console.log('Already connected to CoinDCX WebSocket');
      return;
    }

    this.ws = new WebSocket(this.wsURL);
    
    this.ws.on('open', () => {
      console.log('Connected to CoinDCX WebSocket');
      this.isConnected = true;
      this.reconnectAttempts = 0;
      this.emit('connected');
      
      // Subscribe to USDT/INR market
      this.subscribeTicker();
      this.subscribeOrderBook();
      
      // Setup ping to keep connection alive
      this.setupPing();
    });

    this.ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.event === 'ticker-update') {
          this.emit('ticker', message.data);
        } else if (message.event === 'depth-update') {
          this.emit('orderbook', message.data);
        } else if (message.event === 'error') {
          this.emit('error', new Error(message.message || 'WebSocket error'));
        }
      } catch (error) {
        this.emit('error', error);
      }
    });

    this.ws.on('close', () => {
      console.log('Disconnected from CoinDCX WebSocket');
      this.isConnected = false;
      this.clearPing();
      
      if (this.reconnectAttempts < this.maxReconnectAttempts) {
        this.reconnectAttempts++;
        const delay = Math.min(this.reconnectTimeout * Math.pow(2, this.reconnectAttempts - 1), 30000);
        console.log(`Reconnecting in ${delay}ms... (attempt ${this.reconnectAttempts})`);
        setTimeout(() => this.connect(), delay);
      } else {
        this.emit('error', new Error('Max reconnection attempts reached'));
      }
    });

    this.ws.on('error', (err) => {
      console.error('CoinDCX WebSocket error:', err);
      this.emit('error', err);
    });
  }

  disconnect() {
    this.clearPing();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }

  private setupPing() {
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.ping();
      }
    }, 30000);
  }

  private clearPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private subscribeTicker() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const subscribeMessage = {
        event: 'join',
        streams: ['I-USDT_INR@ticker']
      };
      this.ws.send(JSON.stringify(subscribeMessage));
    }
  }

  private subscribeOrderBook() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const subscribeMessage = {
        event: 'join',
        streams: ['I-USDT_INR@depth']
      };
      this.ws.send(JSON.stringify(subscribeMessage));
    }
  }

  private getTimestamp(): number {
    return Math.floor(Date.now() / 1000);
  }

  private createSignature(payload: string): string {
    return crypto
      .createHmac('sha256', this.apiSecret)
      .update(payload)
      .digest('hex');
  }

  private async makeAuthenticatedRequest(method: string, path: string, body?: any): Promise<any> {
    await this.rateLimitCheck();

    const requestBody = body ? JSON.stringify(body) : '';
    
    // Create payload for signature
    const payloadToSign = requestBody || '';
    const signature = this.createSignature(payloadToSign);

    const headers = {
      'X-AUTH-APIKEY': this.apiKey,
      'X-AUTH-SIGNATURE': signature,
      'Content-Type': 'application/json'
    };

    try {
      const response = await this.client.request({
        method,
        url: path,
        data: body,
        headers
      });

      return response.data;
    } catch (error: any) {
      if (error.response) {
        throw new Error(`CoinDCX API Error: ${error.response.data.message || error.response.statusText}`);
      }
      throw error;
    }
  }

  private async rateLimitCheck(): Promise<void> {
    const now = Date.now();
    this.lastRequest = this.lastRequest.filter(ts => now - ts < 1000);
    if (this.lastRequest.length >= this.rateLimit) {
      await new Promise(res => setTimeout(res, 100));
      return this.rateLimitCheck();
    }
    this.lastRequest.push(now);
  }

  // Public API Methods (No authentication required)
  async getTicker(market: string = 'I-USDT_INR'): Promise<Ticker> {
    await this.rateLimitCheck();
    
    try {
      const response = await this.client.get(`/exchange/ticker`, {
        params: { market }
      });
      return response.data[0];
    } catch (error) {
      throw new Error(`Failed to get ticker: ${error}`);
    }
  }

  async getOrderBook(market: string = 'I-USDT_INR'): Promise<any> {
    await this.rateLimitCheck();
    
    try {
      const response = await this.client.get(`/market_data/orderbook`, {
        params: { pair: market }
      });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get order book: ${error}`);
    }
  }

  // Authenticated API Methods
  async getBalance(): Promise<Balance[]> {
    const balances = await this.makeAuthenticatedRequest('POST', '/exchange/v1/users/balances', {});
    return balances;
  }

  async getUSDTBalance(): Promise<number> {
    const balances = await this.getBalance();
    const usdtBalance = balances.find((b: Balance) => b.currency === 'USDT');
    return usdtBalance ? parseFloat(usdtBalance.balance.toString()) : 0;
  }

  async getINRBalance(): Promise<number> {
    const balances = await this.getBalance();
    const inrBalance = balances.find((b: Balance) => b.currency === 'INR');
    return inrBalance ? parseFloat(inrBalance.balance.toString()) : 0;
  }

  async createOrder(order: OrderRequest): Promise<any> {
    const orderData = {
      side: order.side,
      order_type: order.order_type,
      market: order.market,
      price_per_unit: order.price_per_unit,
      total_quantity: order.total_quantity,
      timestamp: this.getTimestamp()
    };

    const result = await this.makeAuthenticatedRequest('POST', '/exchange/v1/orders/create', orderData);
    return result;
  }

  async getOrderStatus(orderId: string): Promise<any> {
    const result = await this.makeAuthenticatedRequest('POST', '/exchange/v1/orders/status', {
      id: orderId
    });
    return result;
  }

  async cancelOrder(orderId: string): Promise<any> {
    const result = await this.makeAuthenticatedRequest('POST', '/exchange/v1/orders/cancel', {
      id: orderId
    });
    return result;
  }

  async getActiveOrders(market?: string): Promise<any[]> {
    const body = market ? { market } : {};
    const orders = await this.makeAuthenticatedRequest('POST', '/exchange/v1/orders/active_orders', body);
    return orders.orders || [];
  }

  async getTradeHistory(market?: string, limit: number = 100): Promise<any[]> {
    const body = {
      market,
      limit
    };
    const trades = await this.makeAuthenticatedRequest('POST', '/exchange/v1/orders/trade_history', body);
    return trades.trades || [];
  }

  // Helper method to create a market buy order
  async marketBuy(amount: number): Promise<any> {
    return this.createOrder({
      market: 'I-USDT_INR',
      side: 'buy',
      order_type: 'market_order',
      total_quantity: amount
    });
  }

  // Helper method to create a market sell order
  async marketSell(amount: number): Promise<any> {
    return this.createOrder({
      market: 'I-USDT_INR',
      side: 'sell',
      order_type: 'market_order',
      total_quantity: amount
    });
  }

  // Helper method to create a limit buy order
  async limitBuy(amount: number, price: number): Promise<any> {
    return this.createOrder({
      market: 'I-USDT_INR',
      side: 'buy',
      order_type: 'limit_order',
      total_quantity: amount,
      price_per_unit: price
    });
  }

  // Helper method to create a limit sell order
  async limitSell(amount: number, price: number): Promise<any> {
    return this.createOrder({
      market: 'I-USDT_INR',
      side: 'sell',
      order_type: 'limit_order',
      total_quantity: amount,
      price_per_unit: price
    });
  }
}
