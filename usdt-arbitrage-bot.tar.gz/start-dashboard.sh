#!/bin/bash

echo "🚀 Starting USDT Arbitrage Bot Dashboard..."
echo "📊 Dashboard will be available at http://localhost:3000"
echo ""

# Start the server with monitoring
npm run dev